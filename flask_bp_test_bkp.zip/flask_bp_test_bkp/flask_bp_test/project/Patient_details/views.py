__author__ = 'praveen'



from flask import Blueprint,render_template


################
#### config ####
################

patient_details_blueprint = Blueprint(
    'Patient_details',__name__, template_folder ='templates'
)


@patient_details_blueprint.route('/patient_details')
def patient_details():
    return render_template('Patient_Details.html')