__author__ = 'praveen'

from pymongo import MongoClient
from project import bcrypt


def register(mode, reg_details):
    MONGO_HOST = 'localhost'
    MONGO_PORT = 27017
    MONGO_SCHEMA = 'smthealth'
    MONGO_COL_SC = 'logincred'

    connection = MongoClient(MONGO_HOST, MONGO_PORT)

    if mode == 'register':
        collection_MONGO_COL_SC = connection[MONGO_SCHEMA][MONGO_COL_SC]
        collection_MONGO_COL_SC.insert({'username':reg_details['username'],'password':reg_details['password']})


def login_check(mode, srch_stng):
    MONGO_HOST = 'localhost'
    MONGO_PORT = 27017
    MONGO_SCHEMA = 'smthealth'
    MONGO_COL_SC = 'logincred'

    connection = MongoClient(MONGO_HOST, MONGO_PORT)

    if mode == 'login':
        collection_MONGO_COL_SC = connection[MONGO_SCHEMA][MONGO_COL_SC]
        usr_nm_pwd = srch_stng
        result_var = collection_MONGO_COL_SC.find({'username': usr_nm_pwd}, projection={"_id": 0}, limit=1)
        assert isinstance(result_var, object)
        return result_var