#################
#### imports ####
#################

from flask import  Blueprint,render_template,request,redirect,session,flash,url_for   # pragma: no cover
from project.models import login_check,bcrypt,register
from flask_login import  login_user,login_required, logout_user
from functools import wraps
#from .forms import LoginForm

################
#### config ####
################

users_blueprint = Blueprint(
    'users', __name__,template_folder = 'templates'
)   # pragma: no cover

def login_required(f):
    @wraps(f)
    def wrap(*args, **kwargs):
        if 'logged_in' in session:
            return f(*args, **kwargs)
        else:
            flash('you need to login first.')
            return redirect(url_for('users.login'))
    return wrap



@users_blueprint.route('/')
@login_required
#def login():
#    return render_template('login.html')


#@users_blueprint.route('/welcome')
def welcome():
    return render_template('welcome.html')

@users_blueprint.route('/login', methods=['GET','POST'])
def login():
    error = None
    #form = LoginForm(request.form)
    if request.method == 'POST':
        #if form.validate_on_submit():
        FRM_USER_NAME = request.form['username']
        FRM_PASSWORD  = request.form['password']
        DB_USER_NM_PWD  = login_check('login', FRM_USER_NAME)

        for DB_USER_NM_PWD in DB_USER_NM_PWD:

            DB_USER_NM = DB_USER_NM_PWD['username']
            DB_USER_PWD =  DB_USER_NM_PWD['password']

            if ( FRM_USER_NAME != DB_USER_NM and DB_USER_PWD != FRM_PASSWORD ):
                error = 'Invalid credentials please try again'
            else:
                #login_user(DB_USER_NM)
                session['logged_in'] = True
                flash('You were logged in. Go Crazy.')
                return redirect(url_for('users.welcome'))
    return render_template('login.html', error=error)

@users_blueprint.route('/registration', methods=['GET', 'POST'])
def registration():
    error = None
    if request.method == 'POST':
        FRM_USER_NAME = request.form['email']
        FRM_PASSWORD  = request.form['password']
        FRM_CPASSWORD  = request.form['cpassword']

        if ( FRM_PASSWORD != FRM_CPASSWORD  ):
            error = 'password does not match please try again'
        else:

                    REG_DETAILS = {}
                    REG_DETAILS['username'] = FRM_USER_NAME
                    REG_DETAILS['password'] = bcrypt.generate_password_hash(FRM_CPASSWORD)
                    register('register', REG_DETAILS)

                    session['logged_in'] = True
                    flash('You were logged in. Go Crazy.')
                    return redirect(url_for('users.welcome'))

    return render_template('registration.html', error=error)


@users_blueprint.route('/logout')
def logout():
#    logout_user()
    flash('You were logged out.')
    session.pop('logged_in', None)
    return redirect(url_for('users.login'))