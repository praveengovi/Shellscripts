__author__ = 'praveen'


#################
#### imports ####
#################

from flask import Flask
from flask_bcrypt import Bcrypt
from flask_login import LoginManager


import os

################
#### config ####
################

app = Flask(__name__)
app.secret_key = "1234"

login_manager = LoginManager(app)
login_manager.init_app(app)

bcrypt = Bcrypt(app)
#app.config.from_object(os.environ['APP_SETTINGS'])

from project.users.views import users_blueprint
from project.Patient_details.views import patient_details_blueprint

# register our blueprints
app.register_blueprint(users_blueprint)
app.register_blueprint(patient_details_blueprint)



